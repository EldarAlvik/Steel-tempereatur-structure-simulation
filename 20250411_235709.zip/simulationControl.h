#pragma once
#include "std_lib_facilities.h"
#include "animation/animation.h"
#include "simulationLogic/enviorment.h"
#include "simulationLogic/simulation.h"




bool runSimulation();