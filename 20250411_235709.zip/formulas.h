#pragma once
#include "std_lib_facilities.h"


bool distanceBetweenTwoPoints(unsigned int x1,unsigned int y1,unsigned int x2,unsigned int y2);