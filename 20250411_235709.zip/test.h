#pragma once
#include "std_lib_facilities.h"
#include "atomAndStructure/atom.h"
#include "animation/animation.h"

void carbonTest();


// void animationTest();